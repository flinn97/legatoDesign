import React, { Component } from 'react';

class Studentinfo extends Component {
    constructor(props) {
        //create state
        super(props);
        this.state = {
            
        };
    }
    

    render() {
       

        return (
            <div className="smallcardleft" >
            <h3>Student Name</h3>
            <div style={{display:"flex", flexDirection:"column"}}>
               
            </div>
            </div>

               
        );
    }
}

export default Studentinfo;