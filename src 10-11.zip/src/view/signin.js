import React, { Component } from "react";
import AuthService from "../services/auth.service";
import Student from "./mystudents";
import Opps from "../npm/compontsList";
import OppsFactory from "../npm/operationsFactory";
import loading from "../assets/loading.gif";


export default class Login extends Component {
   
    //state creation and binding.
    constructor(props) {
        super(props);
        this.handleLogin = this.handleLogin.bind(this);
        this.handleChange = this.handleChange.bind(this);
        //this.onChangePassword = this.onChangePassword.bind(this);

        this.state = {
            
            done:false,
            email:"",
            password:"",
            loading:false,
            messageSwitch: false,
            currentMessage:"",
            message:{
                wrongPassword:"Email or password was incorrect please try again.",
                email:"Please fill out the required fields.",
                

            },
            attempt: 0,
            tooManyLoginAttempts:false
        };
    }


    //handles all changes with state.
    handleChange = (event) => {
        
        const { name, value } = event.target

        this.setState({
            [name]: value,
        })
    }
    componentDidMount(){
        window.addEventListener('keydown', (e)=>{
            
            if(e.key==="Enter"){
                
                // e.preventDefault();
                this.handleLogin(e);
                
            }
        })
    }

    //submites for login using the controller to connect with backend. Sends to the teacher profile if teacher or the student if back end spits out student.
    async handleLogin(e,) {
        
        if(this.state.attempt>=10){
            this.setState({
                tooManyLoginAttempts:true,
            })
            return;
        }
        else{
            this.setState({
                attempt: this.state.attempt+1
            })
        }
        if(this.state.email===""){
            this.setState({
                messageSwitch:true,
                currentMessage:this.state.message.email,
                loading:false,
            })
            return
        }
        await this.setState({
            loading:true
        })
        e.preventDefault();
        let email = this.state.email
        let password = this.state.password
        let student = false;
        let teacher = false;
        if(this.state.student){
            let getEmail = await AuthService.getStudentsTeacher(email+"@legato.com");
            email = email+"@legato.com";
            teacher = getEmail.email;
            password = this.state.email;
            student = this.state.email;
            this.props.app.dispatch({firstTime:true})
        }
        else{
            let s = await AuthService.getStudentsTeacher(email);
            if(s?.student){
                student= s._id;
                teacher= s.email;
            }
        }
        let user = await AuthService.login(email, password, this.props.app.state.componentList, student, teacher);
        
        if(user){
            if(!student){
                window.location.reload();

            }
            else{
            await AuthService.getAllTheDataForTheUser(email, this.props.app.state.componentList, student, teacher, this.props.app.dispatch);

            }

        }
        else{
            this.setState({
                messageSwitch:true,
                loading:false,
                currentMessage:this.state.message.wrongPassword
            })
        }
    }


    render() {
        
        //login page for the screen. 
        return (
            <div style={{width:"100%", height:"100%"}}>
                <div style={{width:"100%", height:"50px"}} onClick={()=>{
                    this.props.app.dispatch({operate: "adduser", operation:"cleanPrepare", login:false});
                }}>
                    Register
                </div>
            <div className="col-md-12">
                <div className="card card-container">
                    <img src="//ssl.gstatic.com/accounts/ui/avatar_2x.png" alt="profile-img" className="profile-img-card"/>
                    {this.state.forgot?(<>
                    
                        <div className="form-group">
                                    <label htmlFor="Email">{this.state.student?(<>Code</>):(<>Please enter your email</>)}</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        name="email"
                                        value={this.state.email}
                                        onChange={this.handleChange}
                                        maxLength="30"
                                    />
                                </div></>):(
                    <>
                                <div className="form-group">
                                    <label htmlFor="Email">{this.state.student?(<>Code</>):(<>Email</>)}</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        name="email"
                                        value={this.state.email}
                                        onChange={this.handleChange}
                                        maxLength="30"
                                    />
                                </div>
                            {!this.state.student&&(
                                <div className="form-group">
                                    <label htmlFor="password">Password</label>
                                    <input
                                        type="password"
                                        className="form-control"
                                        name="password"
                                        value={this.state.password}
                                        onChange={this.handleChange}
                                        maxLength="20"

                                    />
                                </div>)}
                                </>)}
                                {this.state.forgot?(<>
                                    <div className="form-group" style={{marginTop:"37px"}}>
                                    <button className="btn  btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF", width: "85spx" }} onClick={AuthService.sendForgotPasswordChange.bind(this,this.state.email)} >
                                        <span>Submit</span>
                                    </button>
                                </div></>):(
                                <div className="form-group" style={{marginTop:"37px"}}>
                                    <button className="btn  btn-block" style={{ background: "#696eb5", height: "35px", color: "#F0F2EF", width: "85spx" }} onClick={this.handleLogin} >
                                        <span>{this.state.loading?(<><img src={loading} style={{width:"20px", height:"20px"}}/>Loading...</>):(<>Login</>)}</span>
                                    </button>
                                    {this.state.messageSwitch&&(<div style={{color:"red"}}>{this.state.currentMessage}</div>)}
                                </div>
                                )}
                               {!this.state.student? (<div style={{color:"blue", cursor:"pointer", textDecoration:"underline"}} onClick={()=>{this.setState({student:true})}}>Have a Code?</div>):(<div style={{color:"blue", cursor:"pointer", textDecoration:"underline"}} onClick={()=>{this.setState({student:false})}}>back</div>)}
                                <div style={{color:"blue", cursor:"pointer", textDecoration:"underline"}} onClick={()=>{this.setState({forgot:true})}}>forgot password?</div>
                   
                    
                </div>
            </div>
            </div>
        );
    }
}